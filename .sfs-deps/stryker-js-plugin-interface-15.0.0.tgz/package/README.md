# @systemfsoftware/stryker-js-plugin-interface

The mutation-testing plugin **contract**. A worker plugin — a test runner,
checker, or reporter — ships a spawn entrypoint whose target hosts an `RpcServer`
for its kind's `@effect/rpc` group; the host resolves that entrypoint from the
project's config, spawns it, and drives it over NDJSON. Every payload crossing
the boundary is a schema this package owns, and every failure is a typed variant.
The concept modules a plugin implements — the test-runner and checker services and
the schemas they carry — ship from this package too.

The boundary ships as two packages:

- **`@systemfsoftware/stryker-js-plugin-interface`** (this one) — what both sides
  of the process split must agree on: the RPC groups, their payload and error
  schemas, the spawn contract, and the trace-context contract.
- **[`@systemfsoftware/stryker-js-plugin-runtime`](../stryker-js-plugin-runtime/README.md)**
  — the worker-side implementation a plugin process runs: the RPC server layer,
  its Node module port, its OTel bootstrap, the worker-options wire codec, and the
  trace-context middleware implementations.

## Install

```sh
pnpm add @systemfsoftware/stryker-js-plugin-interface
```

A plugin process also installs the runtime package:

```sh
pnpm add @systemfsoftware/stryker-js-plugin-runtime
```

## Entry point

The interface package groups its exports into namespaces. `Plugin` holds the per-kind RPC groups (`TestRunnerRpcs`,
`CheckerRpcs`, `ReporterRpcs`), the boundary payload schemas
(`TestRunnerDryRunRequest`, `CheckerRequest`, `ReporterEventBatch`,
`ReporterInitOptions`, …), the typed error taxonomy (`BoundaryPayloadRejected`,
`BoundaryUnrecognizedSignal`) and the spawn contract (`WorkerPluginKind`,
`WorkerPluginSpawn`, `WorkerPluginSpawnSchema`, `WorkerEntryUrl`). `Trace` holds
the trace-context contract the groups carry (`TraceContextMiddleware`,
`PropagatedTrace`, `TracedRpc`, `TraceContextReference`, `TraceContextParts`,
`Traceparent`, `TraceparentHeader`, `TracestateHeader`). `Checker`,
`TestRunner`, `Evaluator`, `Reporter`, `Report` and `Options` hold each plugin
kind's contract, the mutation report and the Stryker options. `Mutant` holds
mutant identity, status and location (`Mutant`, `MutantId`, `MutatorName` with
its `<namespace>/<Name>` grammar, `CanonicalFileName`, `MutantStatusSchema`
with its status subsets, `Location`, `Position`) together with the run-options
and coverage payloads a test runner receives (`MutantRunOptionsSchema`,
`MutantCoverageSchema`). `MutatorCatalog` holds the catalog entry shape a
provider authors (`Entry`, `Id`, `Tier`, `Definition`, `Example`, `Provider`),
and `MutatorProvider` holds the contribution a mutator plugin's module exports
(`Contribution`, `ProviderEntry`, `Implementation`):

```ts
import { Plugin } from '@systemfsoftware/stryker-js-plugin-interface'

Plugin.TestRunnerRpcs
```

The runtime package's `Worker` namespace publishes the worker server layer a
plugin's `main.ts` launches (`workerServerLayer`, `WorkerServerParams`), the
worker-options wire schema and its service (`WorkerOptionsWire`,
`WorkerOptions`), and the telemetry service a worker root binds its OTel SDK
from (`WorkerTelemetry`). Its `Trace` namespace publishes the trace-context
implementations (`layerTraceContextClient`, `layerTraceContextServer`,
`withLinkedSpan`, `TraceContextPartsFromEffectSpan`):

```ts
import { Trace, Worker } from '@systemfsoftware/stryker-js-plugin-runtime'
```

Telemetry is a layer everywhere: a worker root reads `WorkerTelemetry` and binds
its own `NodeSdk.layer`-based exporter, and a host provides its own
`NodeSdk.layer`-based layer at its composition root. Both are no-ops unless
`OTEL_ENABLED` is `true`.

## Mutator providers

A plugin can contribute mutators. The library module the host executes to read
the plugin's descriptor exports `strykerMutators`, a
`MutatorProvider.Contribution`:

```ts
import { MutatorProvider } from '@systemfsoftware/stryker-js-plugin-interface'

export const strykerMutators: MutatorProvider.Contribution = {
  namespace: 'acme',
  entries: [
    {
      id: 'swap-arguments',
      name: 'acme/SwapArguments',
      tier: 'default',
      definition: 'swaps the two arguments of a two-argument call',
      examples: [{ before: 'f(a, b)', after: ['f(b, a)'] }],
      implementation: (node, context) => [/* replacement nodes */],
    },
  ],
}
```

An entry's `id` is a lowercase kebab-case catalog id, and its `name` is a
PascalCase mutator name whose prefix is the provider that owns it: the stock
`stryker` provider owns the unprefixed names, and a plugin owns
`<namespace>/<Name>`. `tier` is `'default'` or `'optIn'`, `definition` is the
authored prose, `examples` carries at least one before/after pair, and
`implementation` is the `(node, context) => Iterable<Node>` the instrumenter
runs, with `MutatorContext` carrying the parent, grandparent and ancestor nodes.

The catalog is refined where it is declared: a duplicated id or name, a provider
that does not own a name, an entry with no examples, and an example whose
`before` is empty are refused. At load time the run is refused before
instrumentation when two providers declare one namespace, when a catalog claims
a stock mutator name, or when an entry names a mutator its provider does not own.

## The entry a plugin ships

A worker plugin ships one process entrypoint, `src/main.ts`. That file launches
`workerServerLayer(...)` through its platform's `runMain` — the single place the
worker program is interpreted, the same shape the `stryker` CLI's own `main.ts`
takes — and the package declares the built artifact at the `./worker` subpath of
its exports map, which is where the host resolves a worker entry from.

```ts
import { Plugin } from '@systemfsoftware/stryker-js-plugin-interface'
import { Worker } from '@systemfsoftware/stryker-js-plugin-runtime'

NodeRuntime.runMain(
  Layer.launch(
    Worker.workerServerLayer({
      rpcs: Plugin.TestRunnerRpcs,
      handlers: testRunnerHandlers,
      schemaServices: Layer.empty,
    }),
  ).pipe(Effect.provideService(Logger.LogToStderr, true)),
)
```

## Trust boundary

The host executes a plugin's _library_ module in its own process to read the
plugin's descriptor, its ignorers, and its validation-schema contribution: that
module is trusted code, the same as any other dependency the project installs.
Only the plugin's _runtime work_ crosses into its own process — the RPC groups in
this package are what the host drives there, and a worker that crashes, runs out
of memory, or never boots is reported as a typed boundary error instead of
taking the run down.

A spawned worker inherits the host's environment and reads the run's options from
`options.json` in the worker directory the host creates, so a plugin sees the
same options and environment a local `stryker` run has. Test-runner and checker
workers are started in the run's sandbox directory; a reporter worker is started
in the project root it reports on.

The worker channel is a unix socket the host restricts to its owner on POSIX. On
Windows it is a named pipe: the pipe's name embeds a random UUID, and its default
security descriptor (creator owner, LocalSystem, administrators, read for
Everyone) is not tightened, because `node:net` exposes no API for it. That
residual is recorded, not closed.

## License

Apache-2.0. Part of [systemfsoftware](https://github.com/systemfsoftware/stryker-js-effect/tree/main/packages/stryker-js-plugin-interface#readme).
