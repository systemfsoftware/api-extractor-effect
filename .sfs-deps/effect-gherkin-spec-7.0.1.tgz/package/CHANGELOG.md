# @systemfsoftware/effect-gherkin-spec

## 7.0.1

### Patch Changes

- Updated dependencies:
  - @systemfsoftware/vitest@2.0.0
